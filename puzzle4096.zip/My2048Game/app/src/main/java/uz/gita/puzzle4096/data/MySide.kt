package uz.gita.puzzle4096.data

enum class MySide {
    LEFT, RIGHT, UP, DOWN
}