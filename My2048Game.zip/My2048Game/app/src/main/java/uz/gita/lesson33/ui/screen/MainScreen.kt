package uz.gita.lesson33.ui.screen

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.core.view.get
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import uz.gita.lesson33.R
import uz.gita.lesson33.data.MySide
import uz.gita.lesson33.databinding.ScreenMainBinding
import uz.gita.lesson33.ui.viewmodels.MainViewModel
import uz.gita.lesson33.utils.MyTouchListener
import uz.gita.lesson33.utils.background


class MainScreen : Fragment(R.layout.screen_main) {
    private var _binding: ScreenMainBinding? = null
    private val binding get() = _binding!!
    private val viewModel by viewModels<MainViewModel>()
    private val views = ArrayList<TextView>(16)

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _binding = ScreenMainBinding.bind(view)
        loadView()

        val touchListener = MyTouchListener(requireContext())
        touchListener.setSideListener {
            if (viewModel.isNoWay()) {
                gameFinished()
            }
            when (it) {
                MySide.LEFT -> {
                    viewModel.swipeLeft()
                }
                MySide.RIGHT -> {
                    viewModel.swipeRight()
                }
                MySide.UP -> {
                    viewModel.swipeUp()
                }
                MySide.DOWN -> {
                    viewModel.swipeDown()
                }
            }
        }

        binding.group.setOnTouchListener(touchListener)
        binding.buttonReload.setOnClickListener { viewModel.reload() }

        viewModel.arrayLiveData.observe(viewLifecycleOwner, arrayObserver)
    }

    private fun loadView() {
        for (i in 0 until binding.group.childCount) {
            val l = binding.group[i] as LinearLayoutCompat
            for (j in 0 until l.childCount) {
                views.add(l[j] as TextView)
            }
        }
    }

    private val arrayObserver = Observer<Array<Array<Int>>> {
        for (i in it.indices) {
            for (j in it[i].indices) {
                views[i * 4 + j].apply {
                    text = if (it[i][j] == 0) ""
                    else "${it[i][j]}"
                    setBackgroundResource(background(it[i][j]))
                }
            }
        }
    }

    private fun gameFinished() {
        val bundle = Bundle()
        bundle.putInt("MAX_NUMBER", viewModel.getMaxNumber())

        findNavController().navigate(R.id.action_mainScreen_to_resultScreen, bundle)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}