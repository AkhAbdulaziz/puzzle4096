package uz.gita.lesson33.domain

import uz.gita.lesson33.utils.show
import uz.gita.lesson33.utils.timber
import kotlin.random.Random

class AppRepository private constructor() {
    companion object {
        private lateinit var instance: AppRepository
        fun getRepository(): AppRepository {
            if (!::instance.isInitialized) {
                instance = AppRepository()
            }
            return instance
        }
    }


    private val ADD_AMOUNT = 2

    val array =
        arrayOf(arrayOf(0, 0, 0, 0), arrayOf(0, 0, 0, 0), arrayOf(0, 0, 0, 0), arrayOf(0, 0, 0, 0))

    init {
        start()
    }

    private fun start() {
        val list = ArrayList<Pair<Int, Int>>()
        for (i in 0 until 4) {
            for (j in 0 until 4) {
                if (array[i][j] == 0)
                    list.add(Pair(i, j))
            }
        }
        val index = Random.nextInt(0, list.size)
        var index2 = Random.nextInt(0, list.size)
        while (index2 == index) {
            index2 = Random.nextInt(0, list.size)
        }
        array[list[index].first][list[index].second] = ADD_AMOUNT
        array[list[index2].first][list[index2].second] = ADD_AMOUNT
    }

    private fun addNewAmount() {
        val list = ArrayList<Pair<Int, Int>>()
        for (i in 0 until 4) {
            for (j in 0 until 4) {
                if (array[i][j] == 0)
                    list.add(Pair(i, j))
            }
        }
        if (list.size != 0) {
            val index = Random.nextInt(0, list.size)
            array[list[index].first][list[index].second] = ADD_AMOUNT
        }
    }

    fun getMaxNumber(): Int {
        var maxNumber = 2
        for (i in 0 until 4) {
            for (j in 0 until 4) {
                if (array[i][j] > maxNumber) {
                    maxNumber = array[i][j]
                }
            }
        }
        return maxNumber
    }

    fun isNoWay(): Boolean {
        for (i in 0 until 4) {
            for (j in 0 until 3) {
                if (array[i][j] == array[i][j + 1]) {
                    return false
                }
            }
        }
        for (i in 0 until 4) {
            for (j in 0 until 3) {
                if (array[j][i] == array[j + 1][i]) {
                    return false
                }
            }
        }
        return true
    }

    fun reload() {
        for (i in 0 until 4) {
            for (j in 0 until 4) {
                array[i][j] = 0
            }
        }
        start()
    }

    fun swipeLeft() {
        for (i in array.indices) {
            val list = ArrayList<Int>()
            for (j in 0 until 4) {
                if (array[i][j] != 0)
                    list.add(array[i][j])
            }
            timber(list.show())
            var index = 0
            while (index < list.size - 1) {
                if (list[index] == list[index + 1]) {
                    list[index] *= 2
                    list.removeAt(index + 1)
                }
                index++
            }
            timber(list.show())
            for (j in 0 until 4) {
                if (j < list.size) array[i][j] = list[j]
                else array[i][j] = 0
            }
        }
        addNewAmount()
    }

    fun swipeRight() {
        for (i in array.indices) {
            val list = ArrayList<Int>()
            for (j in array[i].indices) {
                if (array[i][j] != 0)
                    list.add(array[i][j])
            }
            var index = list.size - 1
            while (index > 0) {
                if (list[index] == list[index - 1]) {
                    list[index] *= 2
                    list.removeAt(index - 1)
                    index--
                }
                index--
            }
            for (j in 0 until 4) {
                if (j < 4 - list.size) array[i][j] = 0
                else array[i][j] = list[j - (4 - list.size)]
            }
        }
        addNewAmount()
    }

    fun swipeUp() {
        for (i in 0 until 4) {
            val list = ArrayList<Int>()
            for (j in 0 until 4) {
                if (array[j][i] != 0)
                    list.add(array[j][i])
            }
            timber(list.show())
            var index = 0
            while (index < list.size - 1) {
                if (list[index] == list[index + 1]) {
                    list[index] *= 2
                    list.removeAt(index + 1)
                }
                index++
            }
            timber(list.show())
            for (j in 0 until 4) {
                if (j < list.size) array[j][i] = list[j]
                else array[j][i] = 0
            }
        }
        addNewAmount()
    }

    fun swipeDown() {
        for (i in array.indices) {
            val list = ArrayList<Int>()
            for (j in 0 until 4) {
                if (array[j][i] != 0)
                    list.add(array[j][i])
            }
            var index = list.size - 1
            while (index > 0) {
                if (list[index] == list[index - 1]) {
                    list[index] *= 2
                    list.removeAt(index - 1)
                    index--
                }
                index--
            }
            for (j in 0 until 4) {
                if (j < 4 - list.size) array[j][i] = 0
                else array[j][i] = list[j - (4 - list.size)]
            }
        }
        addNewAmount()
    }


}