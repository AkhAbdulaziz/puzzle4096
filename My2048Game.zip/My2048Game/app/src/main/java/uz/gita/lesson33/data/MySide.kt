package uz.gita.lesson33.data

enum class MySide {
    LEFT, RIGHT, UP, DOWN
}